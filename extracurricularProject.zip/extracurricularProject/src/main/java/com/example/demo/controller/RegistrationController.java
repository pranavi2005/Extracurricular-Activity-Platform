package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Event;
import com.example.demo.model.Registration;
import com.example.demo.model.RegistrationRequest;
import com.example.demo.model.User;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.RegistrationRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.RegistrationService;

@RestController
@RequestMapping("/api")
public class RegistrationController {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private RegistrationService registrationService;
	
	@PostMapping("/register")
	public ResponseEntity<?>registerUserToEvent(@RequestBody RegistrationRequest registrationRequest) {
		User user=userRepository.findById(request.getUsername()).orElse(null);
		Event event=eventRepository.findAllById(request.getName()).orElse(null);
		if(user==null||event==null) {
			return ResponseEntity.badRequest().body("Invalid username or event name");
		}
		Registration registration=new Registration();
		registration.setUser(user);
		registration.setEvent(event);
		RegistrationRepository.save(registration);
		return ResponseEntity.ok("User successfully registered for the event");
	}
}

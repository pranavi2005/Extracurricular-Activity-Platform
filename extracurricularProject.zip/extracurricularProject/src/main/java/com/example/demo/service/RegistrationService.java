package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Event;
import com.example.demo.model.Registration;
import com.example.demo.model.User;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.RegistrationRepository;
import com.example.demo.repository.UserRepository;
@Service
public class RegistrationService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private RegistrationRepository registrationRepository;
	
	public void registerforEvent(String username,String name) {
		User user = userRepository.findById(username).orElse(null);
        Event event = eventRepository.findByName(name);
        if (user == null) {
            System.out.println("User not found for username: " + username);
        }
        if (event == null) {
            System.out.println("Event not found for name: " + name);
        }

        if (user != null && event != null) {
            Registration registration = new Registration();
            registration.setUser(user);
            registration.setEvent(event);

            registrationRepository.save(registration);
        }
	}

}

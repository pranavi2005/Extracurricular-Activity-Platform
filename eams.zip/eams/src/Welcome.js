// src/Welcome.js

import React from 'react';
import { Link } from 'react-router-dom';

function Welcome() {
  return (
    <div style={styles.container}>
      <h1 style={styles.mainHeading}>Extracurricular Activity Platform</h1>
      <h2 style={styles.caption}>Explore. Engage. Excel.</h2>
      <p style={styles.description}>
        Extracurricular activity platform is a vibrant community of students passionate about exploring interests beyond academics.
        Our club provides a platform for members to discover new talents, develop skills, and build lifelong connections.
        Join us to unleash your creativity, challenge yourself, and make unforgettable memories.
      </p>
      <Link to="/login">
        <button style={styles.button}>Login</button>
      </Link>
    </div>
  );
}

// Inline Styles
const styles = {
  container: {
    textAlign: 'center',
    padding: '50px',
    fontFamily: 'Arial, sans-serif',
  },
  mainHeading: {
    fontSize: '3rem',
    fontWeight: 'bold',
    color: '#333',
  },
  caption: {
    fontSize: '1.5rem',
    color: '#555',
    margin: '10px 0',
  },
  description: {
    fontSize: '1rem',
    color: '#666',
    maxWidth: '600px',
    margin: '20px auto',
    lineHeight: '1.6',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1rem',
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    marginTop: '20px',
  },
};

export default Welcome;

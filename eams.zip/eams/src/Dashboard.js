import React from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate('/');
  };

  const handleRegisterActivities = () => {
    navigate('/register-activities');
  };

  const handleTrackParticipation = () => {
    navigate('/track-participation');
  };

  const handleEventNotification = () => {
    navigate('/event-notification');
  };

  const handleSubmitFeedback = () => {
    navigate('/submit-feedback');
  };

  return (
    <div style={styles.dashboardContainer}>
      {/* Top Bar */}
      <div style={styles.topBar}>
        <h1 style={styles.heading}>Extracurricular Activity Platform</h1>
        <button onClick={handleLogout} style={styles.logoutButton}>Logout</button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Left Sidebar */}
        <div style={styles.sidebar}>
          <ul style={styles.sidebarList}>
            <li style={styles.sidebarListItem} onClick={handleRegisterActivities}>Register for Activities</li>
            <li style={styles.sidebarListItem} onClick={handleTrackParticipation}>Track Participation</li>
            <li style={styles.sidebarListItem} onClick={handleEventNotification}>Event Notifications</li>
            <li style={styles.sidebarListItem} onClick={handleSubmitFeedback}>Submit Feedback</li>
          </ul>
        </div>

        {/* Welcome Section with Image */}
        <div style={styles.welcomeSection}>
          <div>
            <h2 style={styles.welcomeMessage}>Welcome to the Extracurricular Activity Platform!</h2>
            <img
              src="/images/dashboard-image.jpg"
              alt="Dashboard Visual"
              style={styles.image} // Styling for the image
            />
          </div>
        </div>
      </div>
    </div>
  );
};

// Inline Styles for the Dashboard
const styles = {
  dashboardContainer: {
    fontFamily: 'Arial, sans-serif',
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
  },
  topBar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px',
    backgroundColor: '#007BFF',
    color: '#fff',
  },
  heading: {
    textAlign: 'center',
    flex: 1,
  },
  logoutButton: {
    backgroundColor: '#FF4136',
    color: '#fff',
    border: 'none',
    padding: '10px 15px',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  mainContent: {
    display: 'flex',
    flex: 1,
  },
  sidebar: {
    width: '250px',
    backgroundColor: '#f4f4f4',
    padding: '20px',
    boxShadow: '2px 0 5px rgba(0,0,0,0.1)',
  },
  sidebarList: {
    listStyleType: 'none',
    padding: 0,
  },
  sidebarListItem: {
    margin: '30px 0',
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: '18px',
  },
  welcomeSection: {
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
  },
  welcomeMessage: {
    fontSize: '24px',
    textAlign: 'center',
  },
  image: {
    marginTop: '20px',
    width: '400px',
    height: 'auto', // Ensures the image scales correctly
    borderRadius: '10px', // Adds rounded corners to the image
  },
};

export default Dashboard;
